package kuneri.ersan.com.groupdiscount;

public class ObjectStudent {

    int id;
    String firstname;
    String email;

    public ObjectStudent(){

    }
}